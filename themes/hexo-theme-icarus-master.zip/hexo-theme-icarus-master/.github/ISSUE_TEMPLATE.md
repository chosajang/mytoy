Please make sure you took care of the following things before you submit this issue. Thank you!

- [ ] I have set up and configured my blog according to the [Hexo docs](https://hexo.io/) and the [Icarus docs](https://ppoffice.github.io/hexo-theme-icarus/);
- [ ] I have looked up [Github issues](https://github.com/ppoffice/hexo-theme-icarus/issues) and found no solutions to my problems.
